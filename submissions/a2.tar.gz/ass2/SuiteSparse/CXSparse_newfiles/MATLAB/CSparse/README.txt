MATLAB interface for CXSparse.  See Contents.m for details.

Timothy A. Davis, http://www.suitesparse.com
