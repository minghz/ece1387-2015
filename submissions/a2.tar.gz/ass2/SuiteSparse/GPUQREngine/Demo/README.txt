This GPUQREngine/Demo directory contains a simple demo of the GPUQREngine
package.  "make" will compile and run the demo on a set of randomly constructed
dense matrices.  The output is placed in the troll.m file, and to check the
results, run the troll.m script in MATLAB.

Files:

    README.txt              this file
    Makefile                for compiling and running the C++ demos
    gpuqrengine_demo.cpp    the C++ demo

Timothy A. Davis and Nuri Yeralan, http://www.suitesparse.com
